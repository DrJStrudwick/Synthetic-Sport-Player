from synthSportPlayer.sportplayer import *
from synthSportPlayer.utils import *